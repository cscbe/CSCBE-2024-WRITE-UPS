# To run
docker build . -t green_rev
docker run --rm -it -p 9005:9005 green_rev

Access the challenge at http://localhost:9005/