window.onload = function() {
    Particles.init({
        selector: '.background',
        maxParticles: '150',
        sizeVariations: 5,
        color: ['#7c7c7c', '#000000'],
    });
};