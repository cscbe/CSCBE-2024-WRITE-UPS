Hey there friend!

This is my boss' codebase, he's a bit... angry at life.

Don't mind the comments, I'm sure he doesn't know what he's saying most of the time.

I've already replaced our private keys, I'm sure he wouldn't like it if I gave you that.

Good Luck and safe travels!