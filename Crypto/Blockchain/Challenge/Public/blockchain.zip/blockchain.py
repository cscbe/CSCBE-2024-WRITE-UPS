from Crypto.Protocol.KDF import PBKDF2
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from secrets import token_bytes
import json

from flag import FLAG

class BlockChain:
    
    def __init__(self, secret):
        self.secret = secret
        self.public = [b"\x00"]
        self.private = [b"\x00"]
        self.hashes = [b"\x00"*32]
    
    def __str__(self):
        return " ===> ".join([block.hex() for block in self.public[1:]])
    
    def sign(self, block_content):
        return SHA256.new(block_content + self.secret).digest()

    def encrypt(self, data, nonce, salt):
        block_key = PBKDF2(nonce + self.secret, salt, hmac_hash_module=SHA256, count=1000000)
        iv = token_bytes(16)
        cipher = AES.new(block_key, mode=AES.MODE_CBC, iv=iv)
        return iv + cipher.encrypt(pad(data, 16))

    def new_block(self, data):

        block_number = len(self.public).to_bytes(1, 'big')
        private_block = self.hashes[-1] + data
        encrypted_data = self.encrypt(data, self.private[-1], block_number)
        new_hash = self.sign(private_block)
        
        
        self.private.append(private_block)
        self.public.append(block_number + new_hash + self.hashes[-1] + encrypted_data)
        self.hashes.append(new_hash)


if __name__ == "__main__":
    from random import randint
    
    N = len(FLAG)
    chain = BlockChain(secret=token_bytes(32))
    
    for i in range(N):
        k = randint(1, 10)
        transactions = []
        for _ in range(k):
            transactions.append({"from": hex(randint(2**15, 2**16 - 1)),
                                 "to":  hex(randint(2**15, 2**16 - 1)),
                                 "amount": hex(randint(0, 1000))})
        transactions.append({"flag": FLAG[i]})

        chain.new_block(json.dumps(transactions).encode())
    print(chain)
